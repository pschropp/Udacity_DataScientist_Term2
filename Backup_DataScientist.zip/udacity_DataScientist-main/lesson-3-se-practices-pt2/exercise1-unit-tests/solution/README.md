# Purpose of this Folder

This folder should contain the solution to the exercise. This would be added to a concept walking through the solution with the student for this exercise.