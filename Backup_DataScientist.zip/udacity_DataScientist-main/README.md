# udacity_DataScientist
Code-Snippets (and some videos) of udacity nanodegree course


Dateien / Videos etc. auf:
https://drive.google.com/drive/folders/1i-JLY6U1JksP8Dh9TLP-5zjfyDnFHZxy?usp=sharing
